package com.AQMS.springboot.AirQualityMonitoringSystem;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AirQualityMonitoringSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(AirQualityMonitoringSystemApplication.class, args);
	}

}
